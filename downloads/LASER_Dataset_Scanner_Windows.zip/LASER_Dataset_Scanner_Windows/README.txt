LASER DATASET SCANNER FOR WINDOWS

Purpose
Find additional curated datasets for LASER validation. Scan only the 2024,
2025 and 2026 year folders. Judge RP positive, RP negative, NP positive and
NP negative separately. A dataset is eligible only if all four modes pass.
This tool does not annotate, recalibrate or modify source data.

Start
1. Copy LASER_Dataset_Scanner_Windows.zip to your Windows PC.
2. Right-click the ZIP and choose Extract All. Keep the entire extracted folder.
3. Double-click Start Scanner.cmd. Your normal browser opens the local scanner.
   Keep its small console window open while scanning/copying.
No Python installation, administrator rights, MATLAB, Excel or internet access
is needed once you have the complete portable bundle. Windows 10/11, 64-bit x64.
The bundled Python is from python.org; it runs locally, without installation.

STAGE 1 - SCAN, REPORT AND MEASURE; NO DATASET FILES ARE COPIED
Choose the source. The default is:
G:\divg\GMZ Tandem ms biochemie\Lipidomics
Only its 2024, 2025 and 2026 folders are searched. You may choose one of those
year folders directly. Other years, _Statistics_Archive, .git, raw data and
plot/EIC folders are excluded. Shortcuts/junctions are not followed.

Click Scan 2024-2026. Inspect the per-project PASS/REVIEW/INCOMPLETE/DUPLICATE
results. Expand each project to see its four modes and exact file list.
Checkboxes select PASS datasets only. Selected file count and size update
immediately. These are source bytes to copy, not the size of the entire study.
File hashes are calculated during scanning, which can take time on a network
drive. Reports are saved locally under:
%LOCALAPPDATA%\LASER Dataset Scanner\reports
No dataset collection folder is created in stage 1.

LIVE ACTIVITY AND POSSIBLE STALLS
The activity panel shows the exact folder/file currently being accessed,
folders checked, files seen, projects found, elapsed time and time since the
last real progress update. Expand Recent activity for the latest 50 steps.
Once discovery finishes, dataset checks show a known count. Reading peak lists,
matching curated entries, checking file contents and copying show their own
counts/byte progress. No overall percentage is invented during folder discovery.

After 30 seconds without progress, a warning explains that the current operation
may be waiting on the network drive or reading a large file. After 2 minutes it
is labelled a possible stall, not a confirmed failure. A responding local server
or a running worker is not proof that a blocked network read is advancing.
If the browser cannot reach the scanner for 5 seconds, that separate connection
problem is shown. Keep the scanner console window open.

Cancel immediately acknowledges your request, but Windows/network file access
cannot always be interrupted until the current operation returns. Do not start
another scan while the old job is still active. No source data is modified.
To get this activity panel, close the old scanner, extract the updated full ZIP
into a new folder and launch its Start Scanner.cmd; refreshing an old running
scanner does not update its program files.

STAGE 2 - YOUR APPROVAL, THEN COPY
Choose a destination separate from the source tree. Review the selected size
and file list, tick the approval box, and click Copy approved datasets.
Changing the source or thresholds requires a new scan. Files changed since
the scan are rejected until rescanned. Free disk space is checked first.
Each copied file is hash-verified. Existing dataset folders are never
overwritten. Each completed dataset gets its own folder and collection manifest.
The original file contents and filenames are preserved.

Cancel stops at a safe checkpoint. Completed datasets remain intact. An
interrupted dataset remains in a clearly named .partial_ folder and is NOT
treated as completed. You can inspect/delete such partial copies yourself.
Close scanner stops the local service. Closing only the browser tab does not
stop a running job; use Cancel/Close scanner or the console window.

Files required for a complete candidate
- Four original peakgrouplist_{RP,NP}_{Pos,Neg}.txt files with original IDs and
  per-sample intensity columns. Generated *_annotated.txt files are NOT accepted.
- MS_data.xlsx with curated Primary list (raw) / Equivalents (raw), measured
  m/z, RT, lipid names/adducts/classes and sample profiles.
- RP and NP sample metadata (_RP.xlsx/_RP.csv and _NP.xlsx/_NP.csv), containing
  Mode, File Name, Sample Name and positive Protein correction factors.
- MS_data.mat with saved fitted RT predictions and annotation assignments.
  Supported: MATLAB v5 / compressed v7 MAT files. v7.3/HDF5 or unfamiliar
  layouts are explicitly flagged, never silently passed.

When present and unambiguous, also preserve these small, useful support files:
internal_standards.tsv, group_definition.tsv, analyse_MS_data.m, lipids.tsv,
MS.mat and MS_metadata.mat. These record standards, bounds/settings or saved
annotation definitions for reproducible validation. MATLAB scripts are copied
as data and are never executed. Large instrument raw files, mzML/mzXML, EICs,
Rdata, plots, archives, statistics, reports and existing LASER outputs are NOT
collected. The selected list and exact size are visible before approval.

How quality is assessed
The scanner checks each mode independently using curated entries from the
original workbook, not annotations generated by LASER. It does not infer data
quality from filenames alone or let one good mode conceal another bad mode.

Original-feature correspondence uses measured m/z/RT plus log1p sample-profile
correlation after the supplied Protein correction. Ambiguous/tied matches,
missing sample metadata and unresolved feature mappings remain unknown.

Mass error is the ORIGINAL XCMS feature mass versus the theoretical lipid/adduct
mass from the bundled LASER reference, or a supported workbook chemical formula.
No mass-centering or recalibration is applied. Unknown identities/formulas/adducts
are reported as unassessed, not assumed good. The scanner's own reference is
included in the portable program, not redundantly copied into every dataset.

RT error compares the matched original feature's measured RT with its saved
MATLAB fitted prediction (RTp_grouped). This uses actual saved predictions,
not a fixed historical library RT or a fit invented by the scanner. The saved
fit was made on the curated data: a good residual is NOT independent proof of
correct lipid identity, correct isomer assignment or external accuracy.

Default screening filters, adjustable before stage 1
- At least 50 curated entries and 3 lipid classes in EACH mode.
- At least 80% of entries have matched original features, assessable mass,
  and assessable RT (each coverage requirement checked separately).
- At least 90% of assessable mass errors are strictly below 3 ppm.
- Median absolute mass error no greater than 1.5 ppm.
- At least 90% of assessable RT errors are within 10 seconds.
- Median absolute RT error no greater than 5 seconds.
- Profile correlation at least 0.995, using at least 4 shared sample values.
These are conservative collection filters, not a universal quality standard.
An otherwise usable project can require review because a filter is too strict
for that method. Missing evidence is never a pass. Adjust visibly and rescan;
the selected limits are recorded in every plan and collection manifest.
PASS means suitable under these checks, not that every annotation is correct.

Reports
scan_plan.json: exact source files, sizes/hashes, thresholds and mode checks.
scan_summary.csv: every dataset and all four modes, including unavailable checks.
<dataset_id>_feature_checks.csv: original feature match and ppm/RT evidence for
each curated entry. Percentages state their denominators: correspondence and
assessment coverage use ALL curated entries; error-within-limit percentages
use only entries with that error assessed. Unknown rows are counted separately.
Duplicate selected-file collections are flagged and not automatically copied.
Unreadable source folders are explicitly reported; the scan is not silently
claimed complete. Distinct processing snapshots are not chosen by newest date.

Privacy and limitations
The local browser UI binds only to 127.0.0.1 on a random port, with a random
session token and no outside network requests, uploads, analytics or telemetry.
Only the explicitly selected source is read and destination written. Normal
Windows file permissions apply. No macros, MATLAB scripts or R/pickle code run.
Project structures can differ. Unsupported/ambiguous files need review.
Native Windows launch and network-drive access still require testing on your
actual Windows PC; macOS tests cannot establish those behaviours.

For developers
Source lives under tools/dataset_scanner/, outside annotation runtime.
Build with: python3 tools/build_dataset_scanner.py --output-dir <fresh folder>
CLI scan and copy stages are deliberately separate. Run scanner.py --help in
the portable folder, or python3 -m tools.dataset_scanner.launcher --help from
the repository. Do not modify or bypass a saved plan to copy failed datasets.
